﻿namespace Toth_Norbert_GUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.könyvToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.módosítToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.újToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.törölToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vásárlóToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.újToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.módosítToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.törölToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.vásárlásToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.konyvek = new System.Windows.Forms.ListBox();
            this.vasarlok = new System.Windows.Forms.ListBox();
            this.numericUpDown_darab = new System.Windows.Forms.NumericUpDown();
            this.buttonInsert = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_darab)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.könyvToolStripMenuItem,
            this.vásárlóToolStripMenuItem,
            this.vásárlásToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // könyvToolStripMenuItem
            // 
            this.könyvToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.módosítToolStripMenuItem,
            this.újToolStripMenuItem,
            this.törölToolStripMenuItem});
            this.könyvToolStripMenuItem.Name = "könyvToolStripMenuItem";
            this.könyvToolStripMenuItem.Size = new System.Drawing.Size(52, 20);
            this.könyvToolStripMenuItem.Text = "Könyv";
            // 
            // módosítToolStripMenuItem
            // 
            this.módosítToolStripMenuItem.Name = "módosítToolStripMenuItem";
            this.módosítToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.módosítToolStripMenuItem.Text = "Módosít";
            // 
            // újToolStripMenuItem
            // 
            this.újToolStripMenuItem.Name = "újToolStripMenuItem";
            this.újToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.újToolStripMenuItem.Text = "Új";
            // 
            // törölToolStripMenuItem
            // 
            this.törölToolStripMenuItem.Name = "törölToolStripMenuItem";
            this.törölToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.törölToolStripMenuItem.Text = "Töröl";
            // 
            // vásárlóToolStripMenuItem
            // 
            this.vásárlóToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.újToolStripMenuItem1,
            this.módosítToolStripMenuItem1,
            this.törölToolStripMenuItem1});
            this.vásárlóToolStripMenuItem.Name = "vásárlóToolStripMenuItem";
            this.vásárlóToolStripMenuItem.Size = new System.Drawing.Size(56, 20);
            this.vásárlóToolStripMenuItem.Text = "Vásárló";
            // 
            // újToolStripMenuItem1
            // 
            this.újToolStripMenuItem1.Name = "újToolStripMenuItem1";
            this.újToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.újToolStripMenuItem1.Text = "Új";
            // 
            // módosítToolStripMenuItem1
            // 
            this.módosítToolStripMenuItem1.Name = "módosítToolStripMenuItem1";
            this.módosítToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.módosítToolStripMenuItem1.Text = "Módosít";
            // 
            // törölToolStripMenuItem1
            // 
            this.törölToolStripMenuItem1.Name = "törölToolStripMenuItem1";
            this.törölToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.törölToolStripMenuItem1.Text = "Töröl";
            // 
            // vásárlásToolStripMenuItem
            // 
            this.vásárlásToolStripMenuItem.Name = "vásárlásToolStripMenuItem";
            this.vásárlásToolStripMenuItem.Size = new System.Drawing.Size(60, 20);
            this.vásárlásToolStripMenuItem.Text = "Vásárlás";
            // 
            // konyvek
            // 
            this.konyvek.Dock = System.Windows.Forms.DockStyle.Left;
            this.konyvek.FormattingEnabled = true;
            this.konyvek.Location = new System.Drawing.Point(0, 24);
            this.konyvek.Name = "konyvek";
            this.konyvek.Size = new System.Drawing.Size(251, 426);
            this.konyvek.TabIndex = 1;
            // 
            // vasarlok
            // 
            this.vasarlok.Dock = System.Windows.Forms.DockStyle.Right;
            this.vasarlok.FormattingEnabled = true;
            this.vasarlok.Location = new System.Drawing.Point(559, 24);
            this.vasarlok.Name = "vasarlok";
            this.vasarlok.Size = new System.Drawing.Size(241, 426);
            this.vasarlok.TabIndex = 2;
            // 
            // numericUpDown_darab
            // 
            this.numericUpDown_darab.Location = new System.Drawing.Point(326, 64);
            this.numericUpDown_darab.Name = "numericUpDown_darab";
            this.numericUpDown_darab.Size = new System.Drawing.Size(120, 20);
            this.numericUpDown_darab.TabIndex = 3;
            // 
            // buttonInsert
            // 
            this.buttonInsert.Location = new System.Drawing.Point(339, 134);
            this.buttonInsert.Name = "buttonInsert";
            this.buttonInsert.Size = new System.Drawing.Size(75, 23);
            this.buttonInsert.TabIndex = 4;
            this.buttonInsert.Text = "Megveszem";
            this.buttonInsert.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.buttonInsert);
            this.Controls.Add(this.numericUpDown_darab);
            this.Controls.Add(this.vasarlok);
            this.Controls.Add(this.konyvek);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_darab)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem könyvToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem módosítToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem újToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem törölToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vásárlóToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem újToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem módosítToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem törölToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem vásárlásToolStripMenuItem;
        private System.Windows.Forms.ListBox konyvek;
        private System.Windows.Forms.ListBox vasarlok;
        private System.Windows.Forms.NumericUpDown numericUpDown_darab;
        private System.Windows.Forms.Button buttonInsert;
    }
}

