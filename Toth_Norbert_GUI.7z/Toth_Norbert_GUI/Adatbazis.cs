﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using Org.BouncyCastle.Security;

namespace Toth_Norbert
{
    internal class Adatbazis
    {
        MySqlConnection conn=null;
        MySqlCommand sql=null;

        public Adatbazis()
        {
            MySqlConnectionStringBuilder builder=new MySqlConnectionStringBuilder();
            builder.Server = "localhost";
            builder.UserID = "root";
            builder.Password = "";
            builder.Database = "konyvesbolt2";

            conn = new MySqlConnection(builder.ConnectionString);
            sql = conn.CreateCommand();
            
        }

        internal List<Konyv> getkonyvek()
        {
            List<Konyv> konyv = new List<Konyv>();
            sql.CommandText = "SELECT * FROM `konyv`";
            try
            {
                nyit();
                using (MySqlDataReader dr = sql.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        Konyv uj = new Konyv(dr.GetInt32("konyvid"), dr.GetString("cim"), dr.GetString("isbn"), dr.GetInt32("ar"), dr.GetString("szerzo"));
                        konyv.Add(uj);
                    }
                }
                zar();

            }
            catch (MySqlException ex)
            {

                Console.WriteLine(ex.Message);
            }
            return konyv;
        }

        internal List<Vasarlo> getvasarlok()
        {
            List<Vasarlo> vasarlos = new List<Vasarlo>();
            sql.CommandText = "SELECT * FROM `vasarlo`";
            try
            {
                nyit();
                using (MySqlDataReader dr=sql.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        Vasarlo uj = new Vasarlo(dr.GetInt32("vasarloid"),dr.GetString("nev"),dr.GetString("email_cim"),dr.GetString("felhasznalonev"));
                        vasarlos.Add(uj);
                    }
                }
                zar();

            }
            catch (MySqlException ex)
            {

                Console.WriteLine(ex.Message);
            }
            return vasarlos;
        }

        private void nyit()
        {
            if (conn.State != System.Data.ConnectionState.Open)
            { 
                conn.Open();
            }
        }
        private void zar()
        {
            if (conn.State!=System.Data.ConnectionState.Closed)
            {
                conn.Close();
            }
        }
    }
}
