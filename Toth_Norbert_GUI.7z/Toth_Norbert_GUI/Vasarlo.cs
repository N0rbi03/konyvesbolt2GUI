﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Toth_Norbert
{
    internal class Vasarlo
    {
        public int vasarlloID;
        public string nev;
        public string email_cim;
        public string fellhasznalonev;

        public Vasarlo(int vasarlloID, string nev, string email_cim, string fellhasznalonev)
        {
            this.vasarlloID = vasarlloID;
            this.nev = nev;
            this.email_cim = email_cim;
            this.fellhasznalonev = fellhasznalonev;
        }
        public override string ToString()
        {
            return nev;
        }
    }
}
