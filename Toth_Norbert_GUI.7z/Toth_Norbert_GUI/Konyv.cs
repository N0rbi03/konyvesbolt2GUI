﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Toth_Norbert
{
    internal class Konyv
    {
        public int konyvID;
        public string cim;
        public string isbn;
        public int ar;
        public string szerzo;

        public Konyv(int konyvID, string cim, string isbn, int ar, string szerzo)
        {
            this.konyvID = konyvID;
            this.cim = cim;
            this.isbn = isbn;
            this.ar = ar;
            this.szerzo = szerzo;
        }
    }
}
